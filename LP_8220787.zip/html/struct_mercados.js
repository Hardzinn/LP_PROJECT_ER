var struct_mercados =
[
    [ "contador", "struct_mercados.html#a2c6a3fb7cddd9bd7254692264962b5b3", null ],
    [ "mercados", "struct_mercados.html#af7bb65d10b2b5eae6ee29f2da8e63d52", null ],
    [ "tamanho", "struct_mercados.html#a0a06f50c808099546e057b445cc90c14", null ]
];