var struct_date1 =
[
    [ "ano", "struct_date1.html#ac404d93cbf0169fd9e89edc17d0c5572", null ],
    [ "dia", "struct_date1.html#a3d1171ac670a8e8a672c481f22d1fa9f", null ],
    [ "mes", "struct_date1.html#a9fc86758220eae0e735655f81fd9d9bc", null ]
];