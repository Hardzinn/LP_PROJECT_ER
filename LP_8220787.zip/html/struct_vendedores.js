var struct_vendedores =
[
    [ "contador", "struct_vendedores.html#a2c6a3fb7cddd9bd7254692264962b5b3", null ],
    [ "tamanho", "struct_vendedores.html#a0a06f50c808099546e057b445cc90c14", null ],
    [ "vendedores", "struct_vendedores.html#ac89f4302547f9d76fa8cc9e19734140f", null ]
];