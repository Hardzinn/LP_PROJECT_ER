var struct_comissao =
[
    [ "date_fim", "struct_comissao.html#ac7b3ad0a6b33b24719853968ad92d38d", null ],
    [ "date_inicio", "struct_comissao.html#acd5d11d54f0df5b2544f84e11c2d23d9", null ],
    [ "marketCode", "struct_comissao.html#a2020d778d983aff4df3415e9af2613cd", null ],
    [ "percentage_commision", "struct_comissao.html#a83bf3fdfb6d3b9f07f454ecf471b22d3", null ],
    [ "sellerCode", "struct_comissao.html#aea656dfc81709544a6201c53b6c92b80", null ]
];