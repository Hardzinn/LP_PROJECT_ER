var struct_comissoes =
[
    [ "comissoes", "struct_comissoes.html#a2cc9deb799cac3c058e6468aade39402", null ],
    [ "contador", "struct_comissoes.html#a2c6a3fb7cddd9bd7254692264962b5b3", null ],
    [ "tamanho", "struct_comissoes.html#a0a06f50c808099546e057b445cc90c14", null ]
];