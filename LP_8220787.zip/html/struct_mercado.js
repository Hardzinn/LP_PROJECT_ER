var struct_mercado =
[
    [ "estado", "struct_mercado.html#ac3501eb641d0a848136fb80067de82a5", null ],
    [ "marketCode", "struct_mercado.html#a2020d778d983aff4df3415e9af2613cd", null ],
    [ "marketName", "struct_mercado.html#ac60e71a3f87015bbd5ab81f64e11dd75", null ]
];