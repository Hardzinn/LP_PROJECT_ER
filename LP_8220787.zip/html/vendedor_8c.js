var vendedor_8c =
[
    [ "apagarVendedor", "vendedor_8c.html#a70e43c206d20313d36c3c1fa246ace58", null ],
    [ "atualizarVendedor", "vendedor_8c.html#a532641a4a3acc8f969523cc8bc5b2ab3", null ],
    [ "carregarVendedores", "vendedor_8c.html#abc3c83826013e61a1f9e70cfd7e91d24", null ],
    [ "editarVendedores", "vendedor_8c.html#a739994013d7ebbbe58e08a1589d517e7", null ],
    [ "expandirVendedores", "vendedor_8c.html#af707dcc1314e520e5670a88cd7d721d6", null ],
    [ "guardarVendedores", "vendedor_8c.html#a1ba9940653acc1914c838db18205816f", null ],
    [ "iniciarVendedores", "vendedor_8c.html#a9ccc69fa7d2213f0f5d8d109beba5f92", null ],
    [ "libertarVendedores", "vendedor_8c.html#a6b01fb2144bc9c34c1174af26e2acbb8", null ],
    [ "listarVendedor", "vendedor_8c.html#a262b0908771fa9b5d92aa63ac33bc709", null ],
    [ "listarVendedores", "vendedor_8c.html#a4092971bd8258bf373f12b90d85df196", null ],
    [ "procurarVendedor", "vendedor_8c.html#a74814617ba39a32949c875f7da7b12aa", null ],
    [ "registrarVendedor", "vendedor_8c.html#a77cbd72652fd4f1f8c6df49436e8ac19", null ],
    [ "registrarVendedores", "vendedor_8c.html#a8cc95d67a08b4e4abe6fa5342fa52590", null ],
    [ "removerVendedor", "vendedor_8c.html#aa6a944c57bd8453874187fe152d55a0d", null ],
    [ "vendedorInativo", "vendedor_8c.html#a63a12ca6d5fc44c16a6f4770802ac32a", null ]
];