var mercados_8c =
[
    [ "atualizarMercado", "mercados_8c.html#a5aa14850d7ae6e4cd5620e734faae1a6", null ],
    [ "carregarMercados", "mercados_8c.html#ad74da14b532aa482a178775b7a9eab5f", null ],
    [ "editarMercados", "mercados_8c.html#aab7c730245706672e39e18ce11242826", null ],
    [ "eliminarMercado", "mercados_8c.html#a8a72033b5cbe8395f45da167ab3a2fd5", null ],
    [ "eliminarMercados", "mercados_8c.html#a4c7d69a333b30b7a6632dd866d35de03", null ],
    [ "expandirMercados", "mercados_8c.html#a117a3604f9c653a42284b4e3b22344f9", null ],
    [ "guardarMercados", "mercados_8c.html#afdf3addb5da9d59950d367bdd29c2b6b", null ],
    [ "iniciarMercados", "mercados_8c.html#a411ad8e7ca8226c9efe3bb6ffa0f026f", null ],
    [ "libertarMercados", "mercados_8c.html#aeba585d351384c93aeef36ace9aad7c9", null ],
    [ "listarMercado", "mercados_8c.html#a91997fb9b709cf7d4a98bb9b2cbced24", null ],
    [ "listarMercados", "mercados_8c.html#a9906049dfe42986f769ca3c4521edd5d", null ],
    [ "mercadoInativo", "mercados_8c.html#ab872506756d855f49129aa9ff275a666", null ],
    [ "procurarMercado", "mercados_8c.html#a71db8d1b645921633f9b9dc0369d3dbe", null ],
    [ "registarMercado", "mercados_8c.html#a26071f5509884c39ec6a3df387553590", null ],
    [ "registarMercados", "mercados_8c.html#a759b964931f41ebadfef905920f44f62", null ]
];