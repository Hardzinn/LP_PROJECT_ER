var searchData=
[
  ['vendedorinativo_0',['vendedorInativo',['../vendedor_8c.html#a63a12ca6d5fc44c16a6f4770802ac32a',1,'vendedor.c']]],
  ['verificarsobreposicaodatas_1',['verificarSobreposicaoDatas',['../comissoes_8c.html#a58fbe4275f946507d05efe50440681fd',1,'verificarSobreposicaoDatas(int dia1, int mes1, int ano1):&#160;comissoes.c'],['../structs_8h.html#a58fbe4275f946507d05efe50440681fd',1,'verificarSobreposicaoDatas(int dia1, int mes1, int ano1):&#160;comissoes.c']]]
];
