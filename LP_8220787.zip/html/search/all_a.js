var searchData=
[
  ['name_0',['name',['../struct_vendedor.html#ab6a439e9bf9f53bad54b03c555d29561',1,'Vendedor']]]
];
