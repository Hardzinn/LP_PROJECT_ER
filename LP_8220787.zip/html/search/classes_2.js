var searchData=
[
  ['mercado_0',['Mercado',['../struct_mercado.html',1,'']]],
  ['mercados_1',['Mercados',['../struct_mercados.html',1,'']]]
];
