var searchData=
[
  ['valor_5finvalido_0',['VALOR_INVALIDO',['../input_8c.html#a7dac90953bf2709d6153d7503fe3c77e',1,'input.c']]],
  ['vendedor_1',['Vendedor',['../struct_vendedor.html',1,'']]],
  ['vendedor_2ec_2',['vendedor.c',['../vendedor_8c.html',1,'']]],
  ['vendedor_2eo_2ed_3',['vendedor.o.d',['../vendedor_8o_8d.html',1,'']]],
  ['vendedores_4',['Vendedores',['../struct_vendedores.html',1,'']]],
  ['vendedores_5',['vendedores',['../struct_vendedores.html#ac89f4302547f9d76fa8cc9e19734140f',1,'Vendedores']]],
  ['vendedorinativo_6',['vendedorInativo',['../vendedor_8c.html#a63a12ca6d5fc44c16a6f4770802ac32a',1,'vendedor.c']]],
  ['verificarsobreposicaodatas_7',['verificarSobreposicaoDatas',['../comissoes_8c.html#a58fbe4275f946507d05efe50440681fd',1,'verificarSobreposicaoDatas(int dia1, int mes1, int ano1):&#160;comissoes.c'],['../structs_8h.html#a58fbe4275f946507d05efe50440681fd',1,'verificarSobreposicaoDatas(int dia1, int mes1, int ano1):&#160;comissoes.c']]]
];
