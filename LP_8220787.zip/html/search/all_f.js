var searchData=
[
  ['tamanho_0',['tamanho',['../struct_vendedores.html#a0a06f50c808099546e057b445cc90c14',1,'Vendedores::tamanho()'],['../struct_mercados.html#a0a06f50c808099546e057b445cc90c14',1,'Mercados::tamanho()'],['../struct_comissoes.html#a0a06f50c808099546e057b445cc90c14',1,'Comissoes::tamanho()']]]
];
