var searchData=
[
  ['date1_0',['Date1',['../struct_date1.html',1,'']]]
];
