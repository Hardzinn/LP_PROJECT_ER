var searchData=
[
  ['guardarcomissoes_0',['guardarComissoes',['../comissoes_8c.html#a843b55a0c07d7f9099028f0cdbdd8b8e',1,'guardarComissoes(Comissoes *comissoes, char *ficheiro):&#160;comissoes.c'],['../structs_8h.html#a843b55a0c07d7f9099028f0cdbdd8b8e',1,'guardarComissoes(Comissoes *comissoes, char *ficheiro):&#160;comissoes.c']]],
  ['guardarmercados_1',['guardarMercados',['../mercados_8c.html#afdf3addb5da9d59950d367bdd29c2b6b',1,'guardarMercados(Mercados *mercados, char *ficheiro):&#160;mercados.c'],['../structs_8h.html#afdf3addb5da9d59950d367bdd29c2b6b',1,'guardarMercados(Mercados *mercados, char *ficheiro):&#160;mercados.c']]],
  ['guardarvendedores_2',['guardarVendedores',['../structs_8h.html#a1ba9940653acc1914c838db18205816f',1,'guardarVendedores(Vendedores *vendedores, char *ficheiro):&#160;vendedor.c'],['../vendedor_8c.html#a1ba9940653acc1914c838db18205816f',1,'guardarVendedores(Vendedores *vendedores, char *ficheiro):&#160;vendedor.c']]]
];
