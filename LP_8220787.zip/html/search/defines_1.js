var searchData=
[
  ['commision_5fdb_5ffile_0',['COMMISION_DB_FILE',['../structs_8h.html#a74a3efd30a6b8289bfc80714802ea9cb',1,'structs.h']]],
  ['commision_5fdoesnt_5fexist_1',['COMMISION_DOESNT_EXIST',['../structs_8h.html#af93bf9ee39ccb11e3098937e9f22ac97',1,'structs.h']]],
  ['commision_5fregistred_5fsuccess_2',['COMMISION_REGISTRED_SUCCESS',['../structs_8h.html#a648298b914388da6d3bc765254064357',1,'structs.h']]],
  ['commision_5fseller_5fdoesnt_5fexist_3',['COMMISION_SELLER_DOESNT_EXIST',['../structs_8h.html#ab7f8d97b0ce5b7fd0a5bfbcbe6ac16ba',1,'structs.h']]],
  ['commission_5falready_5fexist_4',['COMMISSION_ALREADY_EXIST',['../structs_8h.html#abb64b75364563516d08b9b9bf24c9c36',1,'structs.h']]]
];
