var searchData=
[
  ['main_0',['main',['../main_8c.html#a3c04138a5bfe5d72780bb7e82a18e627',1,'main.c']]],
  ['mercadoinativo_1',['mercadoInativo',['../mercados_8c.html#ab872506756d855f49129aa9ff275a666',1,'mercados.c']]]
];
