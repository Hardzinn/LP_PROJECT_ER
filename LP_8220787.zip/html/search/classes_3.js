var searchData=
[
  ['vendedor_0',['Vendedor',['../struct_vendedor.html',1,'']]],
  ['vendedores_1',['Vendedores',['../struct_vendedores.html',1,'']]]
];
