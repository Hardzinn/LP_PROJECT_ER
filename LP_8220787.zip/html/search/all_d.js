var searchData=
[
  ['registarmercado_0',['registarMercado',['../mercados_8c.html#a26071f5509884c39ec6a3df387553590',1,'mercados.c']]],
  ['registarmercados_1',['registarMercados',['../mercados_8c.html#a759b964931f41ebadfef905920f44f62',1,'registarMercados(Mercados *mercados):&#160;mercados.c'],['../structs_8h.html#a759b964931f41ebadfef905920f44f62',1,'registarMercados(Mercados *mercados):&#160;mercados.c']]],
  ['registrarcomissao_2',['registrarComissao',['../comissoes_8c.html#a2848ee4953ce7019885ffd0d418d8497',1,'registrarComissao(Comissoes *comissoes, Vendedores *vendedores, Mercados *mercados):&#160;comissoes.c'],['../structs_8h.html#a2848ee4953ce7019885ffd0d418d8497',1,'registrarComissao(Comissoes *comissoes, Vendedores *vendedores, Mercados *mercados):&#160;comissoes.c']]],
  ['registrarcomissoes_3',['registrarComissoes',['../comissoes_8c.html#ac0409bc056b992bf0177b29d2ebdad45',1,'registrarComissoes(Comissoes *comissoes, Vendedores *vendedores, Mercados *mercados):&#160;comissoes.c'],['../structs_8h.html#ac0409bc056b992bf0177b29d2ebdad45',1,'registrarComissoes(Comissoes *comissoes, Vendedores *vendedores, Mercados *mercados):&#160;comissoes.c']]],
  ['registrarvendedor_4',['registrarVendedor',['../vendedor_8c.html#a77cbd72652fd4f1f8c6df49436e8ac19',1,'vendedor.c']]],
  ['registrarvendedores_5',['registrarVendedores',['../structs_8h.html#a8cc95d67a08b4e4abe6fa5342fa52590',1,'registrarVendedores(Vendedores *vendedores):&#160;vendedor.c'],['../vendedor_8c.html#a8cc95d67a08b4e4abe6fa5342fa52590',1,'registrarVendedores(Vendedores *vendedores):&#160;vendedor.c']]],
  ['removervendedor_6',['removerVendedor',['../structs_8h.html#aa6a944c57bd8453874187fe152d55a0d',1,'removerVendedor(Vendedores *vendedores, Comissoes *comissoes):&#160;vendedor.c'],['../vendedor_8c.html#aa6a944c57bd8453874187fe152d55a0d',1,'removerVendedor(Vendedores *vendedores, Comissoes *comissoes):&#160;vendedor.c']]]
];
