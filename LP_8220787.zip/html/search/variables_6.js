var searchData=
[
  ['percentage_5fcommision_0',['percentage_commision',['../struct_comissao.html#a83bf3fdfb6d3b9f07f454ecf471b22d3',1,'Comissao']]],
  ['phone_1',['phone',['../struct_vendedor.html#ae2e2e8a4ea94dd765699711cba3da163',1,'Vendedor']]]
];
