var searchData=
[
  ['editarmercados_0',['editarMercados',['../mercados_8c.html#aab7c730245706672e39e18ce11242826',1,'editarMercados(Mercados *mercados):&#160;mercados.c'],['../structs_8h.html#aab7c730245706672e39e18ce11242826',1,'editarMercados(Mercados *mercados):&#160;mercados.c']]],
  ['editarvendedores_1',['editarVendedores',['../structs_8h.html#a739994013d7ebbbe58e08a1589d517e7',1,'editarVendedores(Vendedores *vendedores):&#160;vendedor.c'],['../vendedor_8c.html#a739994013d7ebbbe58e08a1589d517e7',1,'editarVendedores(Vendedores *vendedores):&#160;vendedor.c']]],
  ['eliminarmercado_2',['eliminarMercado',['../mercados_8c.html#a8a72033b5cbe8395f45da167ab3a2fd5',1,'mercados.c']]],
  ['eliminarmercados_3',['eliminarMercados',['../mercados_8c.html#a4c7d69a333b30b7a6632dd866d35de03',1,'eliminarMercados(Mercados *mercados, Comissoes *comissoes):&#160;mercados.c'],['../structs_8h.html#a4c7d69a333b30b7a6632dd866d35de03',1,'eliminarMercados(Mercados *mercados, Comissoes *comissoes):&#160;mercados.c']]],
  ['expandircomissoes_4',['expandirComissoes',['../comissoes_8c.html#a3fed01c17654470c57dc3ca8d1148346',1,'expandirComissoes(Comissoes *comissoes):&#160;comissoes.c'],['../structs_8h.html#a3fed01c17654470c57dc3ca8d1148346',1,'expandirComissoes(Comissoes *comissoes):&#160;comissoes.c']]],
  ['expandirmercados_5',['expandirMercados',['../mercados_8c.html#a117a3604f9c653a42284b4e3b22344f9',1,'expandirMercados(Mercados *mercados):&#160;mercados.c'],['../structs_8h.html#a117a3604f9c653a42284b4e3b22344f9',1,'expandirMercados(Mercados *mercados):&#160;mercados.c']]],
  ['expandirvendedores_6',['expandirVendedores',['../vendedor_8c.html#af707dcc1314e520e5670a88cd7d721d6',1,'vendedor.c']]]
];
