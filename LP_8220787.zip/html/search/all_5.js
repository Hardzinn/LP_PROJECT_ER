var searchData=
[
  ['file_5ferror_5fcommision_0',['FILE_ERROR_COMMISION',['../structs_8h.html#a2b7f730d21398bf5b3399c3643cc17ef',1,'structs.h']]],
  ['file_5ferror_5fmercados_1',['FILE_ERROR_MERCADOS',['../structs_8h.html#a777c718266c630ae554f4b245f8bc8c7',1,'structs.h']]],
  ['file_5ferror_5fseller_2',['FILE_ERROR_SELLER',['../structs_8h.html#aca7397288f1eaca529b3f391307b91a6',1,'structs.h']]],
  ['full_5fcommision_5flist_3',['FULL_COMMISION_LIST',['../structs_8h.html#aaf14e2b9e53908a67a4a591f5a7e9252',1,'structs.h']]],
  ['full_5flist_5fmarket_4',['FULL_LIST_MARKET',['../structs_8h.html#afff984e67957c43e3b410cbaf55e6def',1,'structs.h']]],
  ['full_5flist_5fseller_5',['FULL_LIST_SELLER',['../structs_8h.html#aec7eb047ed6616786c4b252df63b3b79',1,'structs.h']]]
];
