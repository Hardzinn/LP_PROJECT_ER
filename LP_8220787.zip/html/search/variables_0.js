var searchData=
[
  ['ano_0',['ano',['../struct_date1.html#ac404d93cbf0169fd9e89edc17d0c5572',1,'Date1']]]
];
