var searchData=
[
  ['date2_0',['Date2',['../structs_8h.html#afef5a539a21e02bf26f8ef09ad702c3f',1,'structs.h']]]
];
