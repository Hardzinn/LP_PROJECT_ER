var searchData=
[
  ['seller_5fdb_5ffile_0',['SELLER_DB_FILE',['../structs_8h.html#a5ad9d12d677a41650b028193a241817f',1,'structs.h']]],
  ['seller_5fdesactivation_1',['SELLER_DESACTIVATION',['../structs_8h.html#a97b385b4dc87309c7df08816c173edf4',1,'structs.h']]],
  ['seller_5fdoesnt_5fexist_2',['SELLER_DOESNT_EXIST',['../structs_8h.html#a43d5e3adfea0bf590d090ce10cc7845c',1,'structs.h']]],
  ['status_5fa_3',['STATUS_A',['../structs_8h.html#ac0d6f774cbd1c763115e8e4ed916d71a',1,'structs.h']]],
  ['status_5fd_4',['STATUS_D',['../structs_8h.html#a6961336dd3a1ce81d9e0a9b51416f480',1,'structs.h']]],
  ['status_5fmax_5finput_5',['STATUS_MAX_INPUT',['../structs_8h.html#a0f7b3c581b51a4ed448ad8425bf2c72b',1,'structs.h']]],
  ['success_5fmarket_5fcreation_6',['SUCCESS_MARKET_CREATION',['../structs_8h.html#a3f0306a628e68a21a605ed3886f0cbf9',1,'structs.h']]],
  ['success_5fseller_5fcreation_7',['SUCCESS_SELLER_CREATION',['../structs_8h.html#ad40674fd85e6045c04273910376b1081',1,'structs.h']]]
];
