var searchData=
[
  ['apagarvendedor_0',['apagarVendedor',['../vendedor_8c.html#a70e43c206d20313d36c3c1fa246ace58',1,'vendedor.c']]],
  ['atualizarmercado_1',['atualizarMercado',['../mercados_8c.html#a5aa14850d7ae6e4cd5620e734faae1a6',1,'mercados.c']]],
  ['atualizarvendedor_2',['atualizarVendedor',['../vendedor_8c.html#a532641a4a3acc8f969523cc8bc5b2ab3',1,'vendedor.c']]]
];
