var searchData=
[
  ['editarmercados_0',['editarMercados',['../mercados_8c.html#aab7c730245706672e39e18ce11242826',1,'editarMercados(Mercados *mercados):&#160;mercados.c'],['../structs_8h.html#aab7c730245706672e39e18ce11242826',1,'editarMercados(Mercados *mercados):&#160;mercados.c']]],
  ['editarvendedores_1',['editarVendedores',['../structs_8h.html#a739994013d7ebbbe58e08a1589d517e7',1,'editarVendedores(Vendedores *vendedores):&#160;vendedor.c'],['../vendedor_8c.html#a739994013d7ebbbe58e08a1589d517e7',1,'editarVendedores(Vendedores *vendedores):&#160;vendedor.c']]],
  ['eliminarmercado_2',['eliminarMercado',['../mercados_8c.html#a8a72033b5cbe8395f45da167ab3a2fd5',1,'mercados.c']]],
  ['eliminarmercados_3',['eliminarMercados',['../mercados_8c.html#a4c7d69a333b30b7a6632dd866d35de03',1,'eliminarMercados(Mercados *mercados, Comissoes *comissoes):&#160;mercados.c'],['../structs_8h.html#a4c7d69a333b30b7a6632dd866d35de03',1,'eliminarMercados(Mercados *mercados, Comissoes *comissoes):&#160;mercados.c']]],
  ['email_4',['email',['../struct_vendedor.html#a6c2bb65578063b8b043e7287a5bcb44c',1,'Vendedor']]],
  ['empty_5flist_5',['EMPTY_LIST',['../structs_8h.html#a08ae9c7badcac2d94f0a59844eb6e6cc',1,'structs.h']]],
  ['empty_5flist_5fcommissions_6',['EMPTY_LIST_COMMISSIONS',['../structs_8h.html#ab12223ba8e4be6a73fedad28ef947f13',1,'structs.h']]],
  ['empty_5flist_5fmarket_7',['EMPTY_LIST_MARKET',['../structs_8h.html#ab1a69897cd5f44d2075cded4751aea38',1,'structs.h']]],
  ['estado_8',['estado',['../struct_vendedor.html#ac3501eb641d0a848136fb80067de82a5',1,'Vendedor::estado()'],['../struct_mercado.html#ac3501eb641d0a848136fb80067de82a5',1,'Mercado::estado()']]],
  ['expandircomissoes_9',['expandirComissoes',['../comissoes_8c.html#a3fed01c17654470c57dc3ca8d1148346',1,'expandirComissoes(Comissoes *comissoes):&#160;comissoes.c'],['../structs_8h.html#a3fed01c17654470c57dc3ca8d1148346',1,'expandirComissoes(Comissoes *comissoes):&#160;comissoes.c']]],
  ['expandirmercados_10',['expandirMercados',['../mercados_8c.html#a117a3604f9c653a42284b4e3b22344f9',1,'expandirMercados(Mercados *mercados):&#160;mercados.c'],['../structs_8h.html#a117a3604f9c653a42284b4e3b22344f9',1,'expandirMercados(Mercados *mercados):&#160;mercados.c']]],
  ['expandirvendedores_11',['expandirVendedores',['../vendedor_8c.html#af707dcc1314e520e5670a88cd7d721d6',1,'vendedor.c']]]
];
