var searchData=
[
  ['email_0',['email',['../struct_vendedor.html#a6c2bb65578063b8b043e7287a5bcb44c',1,'Vendedor']]],
  ['estado_1',['estado',['../struct_vendedor.html#ac3501eb641d0a848136fb80067de82a5',1,'Vendedor::estado()'],['../struct_mercado.html#ac3501eb641d0a848136fb80067de82a5',1,'Mercado::estado()']]]
];
