var searchData=
[
  ['carregarcomissoes_0',['carregarComissoes',['../comissoes_8c.html#ae2101acbaa7979f2d5eedb181d65f06b',1,'carregarComissoes(Comissoes *comissoes, char *ficheiro):&#160;comissoes.c'],['../structs_8h.html#ae2101acbaa7979f2d5eedb181d65f06b',1,'carregarComissoes(Comissoes *comissoes, char *ficheiro):&#160;comissoes.c']]],
  ['carregarmercados_1',['carregarMercados',['../mercados_8c.html#ad74da14b532aa482a178775b7a9eab5f',1,'carregarMercados(Mercados *mercados, char *ficheiro):&#160;mercados.c'],['../structs_8h.html#ad74da14b532aa482a178775b7a9eab5f',1,'carregarMercados(Mercados *mercados, char *ficheiro):&#160;mercados.c']]],
  ['carregarvendedores_2',['carregarVendedores',['../structs_8h.html#abc3c83826013e61a1f9e70cfd7e91d24',1,'carregarVendedores(Vendedores *vendedores, char *ficheiro):&#160;vendedor.c'],['../vendedor_8c.html#abc3c83826013e61a1f9e70cfd7e91d24',1,'carregarVendedores(Vendedores *vendedores, char *ficheiro):&#160;vendedor.c']]],
  ['cleaninputbuffer_3',['cleanInputBuffer',['../input_8c.html#a11ac4d3ec555747d95fee8ae7aa18b5d',1,'cleanInputBuffer():&#160;input.c'],['../input_8h.html#a11ac4d3ec555747d95fee8ae7aa18b5d',1,'cleanInputBuffer():&#160;input.c']]]
];
