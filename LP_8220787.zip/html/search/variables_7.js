var searchData=
[
  ['seller_5fcode_0',['seller_code',['../struct_vendedor.html#a2ced43116a92616d2e7a7a31a7755c26',1,'Vendedor']]],
  ['sellercode_1',['sellerCode',['../struct_comissao.html#aea656dfc81709544a6201c53b6c92b80',1,'Comissao']]]
];
