var struct_vendedor =
[
    [ "email", "struct_vendedor.html#a6c2bb65578063b8b043e7287a5bcb44c", null ],
    [ "estado", "struct_vendedor.html#ac3501eb641d0a848136fb80067de82a5", null ],
    [ "name", "struct_vendedor.html#ab6a439e9bf9f53bad54b03c555d29561", null ],
    [ "phone", "struct_vendedor.html#ae2e2e8a4ea94dd765699711cba3da163", null ],
    [ "seller_code", "struct_vendedor.html#a2ced43116a92616d2e7a7a31a7755c26", null ]
];